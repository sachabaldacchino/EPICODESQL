CREATE DATABASE TOYSGROUP_SachaBaldacchino;

USE TOYSGROUP_SachaBaldacchino;

-- creazione tabelle di base come modello logico e le loro chiavi

CREATE TABLE Category (
	CategoryID INT AUTO_INCREMENT PRIMARY KEY,
    CategoryName VARCHAR(50));

CREATE TABLE Product (
	ProductID INT AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(50),
    CategoryID INT,
    CONSTRAINT FK_Category_Product FOREIGN KEY (CategoryID) REFERENCES Category (CategoryID));
    
CREATE TABLE Region (
	RegionID INT AUTO_INCREMENT PRIMARY KEY,
    RegionName VARCHAR(50));

CREATE TABLE Country (
	CountryID INT AUTO_INCREMENT PRIMARY KEY,
    CountryName VARCHAR(50),
    RegionID INT,
    CONSTRAINT FK_Region_Country FOREIGN KEY (RegionID) REFERENCES Region(RegionID));

CREATE TABLE Customer (
	CustomerID INT AUTO_INCREMENT PRIMARY KEY,
    CustomerName VARCHAR(50),
    Address VARCHAR(50),
    CountryID INT,
    CONSTRAINT FK_Country_Customer FOREIGN KEY (CountryID) REFERENCES Country(CountryID));
    
CREATE TABLE Sales (
	SalesID INT AUTO_INCREMENT PRIMARY KEY,
    OrderDate DATE,
    CustomerID INT,
    ProductID INT,
    Quantity INT,
    Price DECIMAL(7,2),
    Amount DECIMAL(9,2),
    CONSTRAINT FK_Product_Sales FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    CONSTRAINT FK_Customer_Sales FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID));

-- Inserimento Dati ho utilizzato chatgpt per inserire i dati

INSERT INTO category (categoryname) VALUES
('Palloni'),
('Bambole'),
('Treni giocattolo'),
('Giocattoli educativi'),
('Costruzioni');

INSERT INTO product (productname, categoryid) VALUES
('Pallone da calcio', 1),
('Pallone da basket', 1),
('Pallone da rugby', 1),
('Bambola parlante', 2),
('Bambola interattiva', 2),
('Bambola di stoffa', 2),
('Treno elettrico', 3),
('Treno a batteria', 3),
('Treno da corsa', 3),
('Libro educativo', 4),
('Set di costruzioni', 4),
('Puzzle educativo', 4),
('Blocchi da costruzione', 5),
('Castello di costruzioni', 5),
('Automobile costruibile', 5),
('Pista per macchinine', 1),
('Gioco di memoria', 4),
('Giocattolo musicale', 2),
('Tavola da disegno interattiva', 4),
('Robot giocattolo', 5);

INSERT INTO region (regionname) VALUES
('North Europe'),
('South Europe'),
('East Europe'),
('West Europe'),
('Central Europe');

INSERT INTO country (countryname, regionid) VALUES
('Svezia', 1),
('Norvegia', 1),
('Italia', 2),
('Spagna', 2),
('Polonia', 3),
('Russia', 3),
('Francia', 4),
('Germania', 4),
('Austria', 5),
('Svizzera', 5);

INSERT INTO customer (customername, address, countryid) VALUES
('Giovanni Rossi', 'Via Roma 12, Milano', 3),
('Maria Bianchi', 'Corso Italia 45, Milano', 3),
('Luca Verdi', 'Piazza del Duomo 10, Milano', 3),
('Carla Gallo', 'Via della Libertà 7, Torino', 3),
('Marco Moretti', 'Viale Europa 5, Roma', 3),
('Anna Russo', 'Via Veneto 3, Roma', 3),
('Stefano Neri', 'Largo Argentina 8, Roma', 3),
('Francesco Bianco', 'Via Garibaldi 30, Napoli', 3),
('Giulia Ferri', 'Piazza San Pietro 15, Roma', 3),
('Lucia Martini', 'Viale delle Rose 20, Firenze', 3),
('Andreas Johansson', 'Kungsgatan 8, Stoccolma', 1),
('Elin Olsson', 'Södra Förstadsgatan 3, Malmö', 1),
('Karl Svensson', 'Drottninggatan 10, Göteborg', 1),
('Pia Andersson', 'Västerlånggatan 5, Stoccolma', 1),
('Petra Nilsson', 'Götgatan 18, Stoccolma', 1),
('Maria Fernandez', 'Calle Mayor 25, Madrid', 2),
('Carlos Garcia', 'Avenida de la Paz 7, Madrid', 2),
('Josefina Sánchez', 'Calle de la Luna 3, Valencia', 2),
('Antonio Pérez', 'Avenida Catalunya 5, Barcelona', 2),
('Fernando López', 'Carrer del Mar 2, Barcellona', 2);

INSERT INTO sales (OrderDate, CustomerID, ProductID, Quantity, Price, Amount) VALUES
('2020-01-15', 1, 1, 2, 15.50, 31.00),
('2020-02-22', 2, 3, 1, 30.00, 30.00),
('2020-03-10', 3, 4, 3, 20.00, 60.00),
('2020-04-18', 4, 5, 1, 50.00, 50.00),
('2020-05-30', 5, 7, 2, 12.00, 24.00),
('2020-06-21', 6, 2, 1, 45.00, 45.00),
('2020-07-12', 7, 8, 4, 10.00, 40.00),
('2020-08-25', 8, 1, 5, 15.50, 77.50),
('2020-09-05', 9, 6, 2, 22.00, 44.00),
('2020-10-16', 10, 4, 1, 20.00, 20.00),
('2021-01-25', 11, 3, 3, 30.00, 90.00),
('2021-02-14', 12, 7, 2, 12.00, 24.00),
('2021-03-17', 13, 9, 1, 18.00, 18.00),
('2021-04-20', 14, 5, 3, 50.00, 150.00),
('2021-05-30', 15, 2, 2, 45.00, 90.00),
('2021-06-18', 16, 6, 4, 22.00, 88.00),
('2021-07-04', 17, 8, 5, 10.00, 50.00),
('2021-08-21', 18, 1, 2, 15.50, 31.00),
('2021-09-06', 19, 10, 3, 25.00, 75.00),
('2021-10-18', 20, 4, 1, 20.00, 20.00),
('2022-01-15', 1, 6, 2, 22.00, 44.00),
('2022-02-22', 2, 9, 1, 18.00, 18.00),
('2022-03-10', 3, 7, 3, 12.00, 36.00),
('2022-04-18', 4, 3, 1, 30.00, 30.00),
('2022-05-30', 5, 5, 4, 50.00, 200.00),
('2022-06-21', 6, 8, 2, 10.00, 20.00),
('2022-07-12', 7, 2, 1, 45.00, 45.00),
('2022-08-25', 8, 4, 5, 20.00, 100.00),
('2022-09-05', 9, 10, 2, 25.00, 50.00),
('2022-10-16', 10, 6, 1, 22.00, 22.00),
('2023-01-25', 11, 3, 4, 30.00, 120.00),
('2023-02-14', 12, 7, 3, 12.00, 36.00),
('2023-03-17', 13, 8, 2, 10.00, 20.00),
('2023-04-20', 14, 9, 1, 18.00, 18.00),
('2023-05-30', 15, 5, 5, 50.00, 250.00),
('2023-06-18', 16, 4, 2, 20.00, 40.00),
('2023-07-04', 17, 2, 3, 45.00, 135.00),
('2023-08-21', 18, 1, 1, 15.50, 15.50),
('2023-09-06', 19, 6, 2, 22.00, 44.00),
('2023-10-18', 20, 3, 4, 30.00, 120.00),
('2024-01-15', 1, 5, 1, 50.00, 50.00),
('2024-02-22', 2, 8, 3, 10.00, 30.00),
('2024-03-10', 3, 10, 2, 25.00, 50.00),
('2024-04-18', 4, 9, 4, 18.00, 72.00),
('2024-05-30', 5, 7, 1, 12.00, 12.00),
('2024-06-21', 6, 1, 3, 15.50, 46.50),
('2024-07-12', 7, 4, 2, 20.00, 40.00),
('2024-08-25', 8, 2, 5, 45.00, 225.00),
('2024-09-05', 9, 6, 1, 22.00, 22.00),
('2024-10-16', 10, 3, 4, 30.00, 120.00),
('2024-11-10', 11, 8, 3, 10.00, 30.00),
('2024-12-30', 12, 5, 2, 50.00, 100.00),
('2025-01-01', 13, 4, 1, 20.00, 20.00),
('2025-02-14', 14, 9, 2, 18.00, 36.00),
('2025-03-17', 15, 7, 5, 12.00, 60.00),
('2025-04-20', 16, 1, 3, 15.50, 46.50),
('2025-05-30', 17, 6, 4, 22.00, 88.00),
('2025-06-21', 18, 10, 2, 25.00, 50.00),
('2025-07-04', 19, 2, 1, 45.00, 45.00),
('2025-08-21', 20, 3, 3, 30.00, 90.00);

-- Query e viste task 4 dell'esercizio




