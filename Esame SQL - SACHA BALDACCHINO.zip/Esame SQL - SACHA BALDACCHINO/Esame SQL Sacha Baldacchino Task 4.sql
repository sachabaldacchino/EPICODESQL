-- Task 4 Esame Sacha Baldacchino

USE toysgroup_sachabaldacchino;

-- 1) Verificare che i campi definiti come PK siano univoci. 
-- In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata).

SELECT 
	categoryid
FROM
	category
GROUP BY
	categoryid
HAVING 
	COUNT(*) > 1;

SELECT
	countryid
FROM
	country
GROUP BY
	countryid
HAVING
	COUNT(*) > 1;

SELECT
	customerid
FROM
	customer
GROUP BY
	customerid
HAVING
	COUNT(*) > 1;

SELECT
	productid
FROM
	product
GROUP BY
	productid
HAVING
	COUNT(*) > 1;

SELECT
	regionid
FROM
	region
GROUP BY
	regionid
HAVING
	COUNT(*) > 1;

SELECT
	salesid
FROM
	sales
GROUP BY
	salesid
HAVING
	COUNT(*) > 1;

-- con queste query che controllano se ci sono chiavi primare doppie, si capisce che sono chiavi primarie in quanto
-- sempre vuote, quindi senza doppi

-- 2)	Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto,
-- la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base 
-- alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)

SELECT
	s.salesid as codice_documento,
    s.orderdate as data_ordine,
    p.productname as prodotto,
    c.categoryname as categoria,
    st.countryname as stato,
    r.regionname as region,
	CASE
		WHEN DATEDIFF(NOW(), s.orderdate) > 180 THEN  '1'
    ELSE  '0'
    END as oltre_180_gg
	FROM category c
	INNER JOIN
    product p
    ON c.categoryid = p.categoryid
    INNER JOIN 
    sales s
    ON s.productid = p.productid
    INNER JOIN
    customer cl
    ON cl.customerid = s.customerid
    INNER JOIN
    country st
    ON st.countryid = cl.countryid
    INNER JOIN
    region r
    ON r.regionid = st.regionid
    ORDER BY
    s.salesid
;

-- 3)	Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate3
-- nell’ultimo anno censito. (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano).
-- Nel result set devono comparire solo il codice prodotto e il totale venduto.

SELECT
	p.productid as codice_prodotto,
    SUM(s.quantity) as tot_quantità
FROM 
	product p
    INNER JOIN
    sales s
    ON p.productid = s.productid
GROUP BY
	p.productid,
    s.orderdate
HAVING
	SUM(s.quantity) > (SELECT 
		AVG(quantity)
    FROM sales) AND
    YEAR(s.orderdate) = (SELECT 
    MAX(YEAR(orderdate))
    FROM sales)
    ;

-- 4)	Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno

SELECT
	p.productname as prodotto,
    YEAR(s.orderdate) as anno,
    SUM(Amount) as fatturato
FROM
	product p
    INNER JOIN
    sales s
	ON p.productid = s.productid
GROUP BY
	p.productid,
    YEAR(s.orderdate);

-- 5)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

SELECT
		st.countryname as stato,
        YEAR(s.orderdate) as anno,
        SUM(s.amount) as fatturato
FROM 
	sales s
    INNER JOIN
    customer c
    ON c.customerid = s.customerid
    INNER JOIN
    country st
    ON st.countryid = c.countryid
GROUP BY
	c.countryid,
    YEAR(s.orderdate)
ORDER BY
	YEAR(s.orderdate) DESC,
    SUM(s.amount) DESC;

-- 6)	Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
-- in base alla query qui sotto, si evince che i Palloni sono la categoria più richiesta
	
SELECT
	c.categoryname as categoria,
    SUM(quantity) as quantità_tot
FROM 
	sales s
    INNER JOIN
    product p
    ON p.productid = s.productid
    INNER JOIN
    category c
    ON c.categoryid = p.categoryid
GROUP BY
	c.categoryid;

-- 7)	Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.

SELECT
	p.productname as prodotti
FROM
	product p
    LEFT JOIN
    sales s
    ON p.productid = s.productid
WHERE 
	s.salesid IS NULL;

SELECT
	p.productname as prodotti
FROM 
	product p
WHERE NOT EXISTS (
					SELECT * 
					FROM sales s 
					WHERE p.productid = s.productid);



-- 8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili
--  (codice prodotto, nome prodotto, nome categoria)

CREATE VIEW vw_Product_category AS(
SELECT
	p.productid,
    p.productname,
    c.categoryname
FROM
	product p
    INNER JOIN 
    category c
    ON p.categoryid = c.categoryid) ;

-- 9)	Creare una vista per le informazioni geografiche

CREATE VIEW vW_info_geographics AS (
SELECT
	c.countryid as codice_paese,
    c.countryname as paese,
    r.regionname as regione
FROM 
	country c
    INNER JOIN
    region r
    ON c.regionid = r.regionid);

